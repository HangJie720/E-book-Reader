package com.yamin.reader.utils;

public class Commons {
	public static boolean isGridViewMode = true;
	public static String shareMsg="我觉得简易小说阅读器不错，现在分享给你们！";
	public static String IS_FAV_BOOK="isfav";
}
