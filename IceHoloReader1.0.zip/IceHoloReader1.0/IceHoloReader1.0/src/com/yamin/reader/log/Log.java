package com.yamin.reader.log;

public class Log {
/*

08-03 09:28:10.820: E/AndroidRuntime(27283): FATAL EXCEPTION: AsyncTask #2
08-03 09:28:10.820: E/AndroidRuntime(27283): java.lang.RuntimeException: An error occured while executing doInBackground()
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.os.AsyncTask$3.done(AsyncTask.java:299)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at java.util.concurrent.FutureTask.finishCompletion(FutureTask.java:352)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at java.util.concurrent.FutureTask.setException(FutureTask.java:219)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at java.util.concurrent.FutureTask.run(FutureTask.java:239)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1080)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:573)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at java.lang.Thread.run(Thread.java:838)
08-03 09:28:10.820: E/AndroidRuntime(27283): Caused by: android.view.ViewRootImpl$CalledFromWrongThreadException: Only the original thread that created a view hierarchy can touch its views.
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.view.ViewRootImpl.checkThread(ViewRootImpl.java:5288)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.view.ViewRootImpl.requestLayout(ViewRootImpl.java:943)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.view.View.requestLayout(View.java:15564)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.view.View.requestLayout(View.java:15564)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.view.View.requestLayout(View.java:15564)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.view.View.requestLayout(View.java:15564)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.widget.ScrollView.requestLayout(ScrollView.java:1443)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.view.View.requestLayout(View.java:15564)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.widget.RelativeLayout.requestLayout(RelativeLayout.java:318)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.view.View.requestLayout(View.java:15564)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.widget.RelativeLayout.requestLayout(RelativeLayout.java:318)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.view.View.requestLayout(View.java:15564)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.widget.AbsListView.requestLayout(AbsListView.java:1862)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.widget.AdapterView$AdapterDataSetObserver.onChanged(AdapterView.java:813)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.widget.AbsListView$AdapterDataSetObserver.onChanged(AbsListView.java:6282)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.database.DataSetObservable.notifyChanged(DataSetObservable.java:37)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.widget.BaseAdapter.notifyDataSetChanged(BaseAdapter.java:50)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at com.yamin.reader.activity.MainActivity.loadShelfData(MainActivity.java:693)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at com.yamin.reader.activity.MainActivity.access$2(MainActivity.java:690)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at com.yamin.reader.activity.MainActivity$sdScanAysnTask.doInBackground(MainActivity.java:637)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at com.yamin.reader.activity.MainActivity$sdScanAysnTask.doInBackground(MainActivity.java:1)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at android.os.AsyncTask$2.call(AsyncTask.java:287)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	at java.util.concurrent.FutureTask.run(FutureTask.java:234)
08-03 09:28:10.820: E/AndroidRuntime(27283): 	... 3 more

 */
}
