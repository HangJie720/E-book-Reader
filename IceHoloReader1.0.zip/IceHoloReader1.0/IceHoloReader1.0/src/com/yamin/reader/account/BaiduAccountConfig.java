package com.yamin.reader.account;

public class BaiduAccountConfig {
	public static final String APIKey = "wrDoGPhZ4Iaq0dRS4LWQIFnM";
	public static final String SecretKey = "Ej6DEbzSyCvSoClYxx2Mj5EPlzdjXvU4";
}
