/*
 * Copyright (C) 2007-2013 Geometer Plus <contact@geometerplus.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 */

package org.geometerplus.zlibrary.core.options;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.geometerplus.zlibrary.core.util.MiscUtil;

public class ZLStringListOption extends ZLOption {
	private final List<String> myDefaultValue;
	private List<String> myValue;
	private final String myDelimiter;

	public ZLStringListOption(String group, String optionName, List<String> defaultValue, String delimiter) {
		super(group, optionName);
		myDefaultValue = (defaultValue != null) ? defaultValue : Collections.<String>emptyList();
		myValue = myDefaultValue;
		myDelimiter = delimiter;
	}

	public ZLStringListOption(String group, String optionName, String defaultValue, String delimiter) {
		super(group, optionName);
		myDefaultValue = (defaultValue != null) ? Collections.singletonList(defaultValue) : Collections.<String>emptyList();
		myValue = myDefaultValue;
		myDelimiter = delimiter;
	}

	public List<String> getValue() {
		if (!myIsSynchronized) {
			final String value = getConfigValue(MiscUtil.join(myDefaultValue, myDelimiter));
			if (value != null) {
				myValue = MiscUtil.split(value, myDelimiter);
			}
			myIsSynchronized = true;
		}
		return Collections.unmodifiableList(myValue);
	}

	public void setValue(List<String> value) {
		if (value == null) {
			value = Collections.emptyList();
		}
		if (myIsSynchronized && (myValue.equals(value))) {
			return;
		}
		myValue = new ArrayList<String>(value);
		if (value.equals(myDefaultValue)) {
			unsetConfigValue();
		} else {
			setConfigValue(MiscUtil.join(value, myDelimiter));
		}
		myIsSynchronized = true;
	}
}
